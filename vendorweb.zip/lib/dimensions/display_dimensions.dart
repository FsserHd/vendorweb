

const mobileWidth = 1200;
