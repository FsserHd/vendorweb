

import 'package:flutter/cupertino.dart';

class MobileDrawerGroceryPage extends StatefulWidget {
  const MobileDrawerGroceryPage({super.key});

  @override
  State<MobileDrawerGroceryPage> createState() => _MobileDrawerGroceryPageState();
}

class _MobileDrawerGroceryPageState extends State<MobileDrawerGroceryPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
