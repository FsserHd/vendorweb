

import 'package:flutter/cupertino.dart';

class DesktopDrawerPage extends StatefulWidget {
  const DesktopDrawerPage(String currentPage, {super.key});

  @override
  State<DesktopDrawerPage> createState() => _DesktopDrawerPageState();
}

class _DesktopDrawerPageState extends State<DesktopDrawerPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
