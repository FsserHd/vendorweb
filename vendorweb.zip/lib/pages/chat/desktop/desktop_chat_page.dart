

import 'package:flutter/cupertino.dart';

class DesktopChatPage extends StatefulWidget {
  const DesktopChatPage({super.key});

  @override
  State<DesktopChatPage> createState() => _DesktopChatPageState();
}

class _DesktopChatPageState extends State<DesktopChatPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
