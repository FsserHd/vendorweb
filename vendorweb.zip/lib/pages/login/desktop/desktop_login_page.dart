
import 'package:flutter/cupertino.dart';

class DesktopLoginPage extends StatefulWidget {

  const DesktopLoginPage({super.key});

  @override
  State<DesktopLoginPage> createState() => _DesktopLoginPageState();
}

class _DesktopLoginPageState extends State<DesktopLoginPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
