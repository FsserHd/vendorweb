

import 'package:flutter/cupertino.dart';

class DesktopReviewPage extends StatefulWidget {
  const DesktopReviewPage({super.key});

  @override
  State<DesktopReviewPage> createState() => _DesktopReviewPageState();
}

class _DesktopReviewPageState extends State<DesktopReviewPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
