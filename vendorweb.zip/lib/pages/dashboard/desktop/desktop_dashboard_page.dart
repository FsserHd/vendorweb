

import 'package:flutter/cupertino.dart';

class DesktopDashboardPage extends StatefulWidget {
  const DesktopDashboardPage({super.key});

  @override
  State<DesktopDashboardPage> createState() => _DesktopDashboardPageState();
}

class _DesktopDashboardPageState extends State<DesktopDashboardPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
