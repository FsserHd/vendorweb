

import 'package:flutter/cupertino.dart';

class DesktopOrderPage extends StatefulWidget {
  const DesktopOrderPage({super.key});

  @override
  State<DesktopOrderPage> createState() => _DesktopOrderPageState();
}

class _DesktopOrderPageState extends State<DesktopOrderPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
